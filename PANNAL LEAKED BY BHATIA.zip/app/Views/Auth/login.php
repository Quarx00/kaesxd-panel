<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-5">
    <div class="col-lg-4">
        <?= $this->include('Layout/msgStatus') ?>
        
        </div>
        
       <marquee width="110%" direction="alternate" height="25px" onmouseover="this.stop();" onmouseout="this.start();">

<strong> <p style="color:black;">⚠️ TODAY ANTICHEAT STATUS ALL VERSION  :- HIGH ⚠️ </strong>          
   </marquee>
        
<nav class="navbar navbar-expand-md navbar-dark bg-danger shadow-sm align-middle" style="background: url(https://i.postimg.cc/YSggD2GY/pexels-eberhard-grossgasteiger-2088205.jpg); no-repeat center center; background-size: 100% 100%; max-width: 80rem;; shadow-lg p-0 mb-5 aria-labelledby="navbarDropdown">

<div class="card-header h1 p-3">
                𝗟𝗼𝗴𝗶𝗻



   <body  background="sundar.jpg" style = " background-repeat: no-repeat;background-size:100% 100%" >

    </body>         </div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-3">
                    <label for="username">Username</label>
                    <input type="text" class="text-success form-control mt-2" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4">
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-primary"><?= $validation->getError('username') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="password">Password</label>
                    <input type="password" class="text-success form-control mt-2" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-primary"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-check mb-3">
                    <label class="form-check-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 55 minutes">
                        <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes">
                        Stay Login
                    </label>
                </div>
                <div class="form-group mb-2">
                    <button type="submit" class="btn btn-danger"><i class="bi bi-arrow-right-circle-fill"> </i> Login in</button>
                 </p>   <a href="<?= site_url('register') ?>" class="btn btn-info">Register here</a>
            </small>
        </p> 
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>


         <p class="text-primary text-muted"> 𝙈𝙖𝙙𝙚 𝘽𝙮 𝘼𝙧𝙢𝙖𝙖𝙣</small></p>
         <marquee  
        
        behavior=alternate><br><a href=""><font color="#e60e8c"></a>
        
        </marquee>
      </div>
<?= $this->endSection() ?>